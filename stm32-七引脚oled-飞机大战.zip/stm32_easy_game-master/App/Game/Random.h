#ifndef _RANDOM_H_
#define _RANDOM_H_

int rand(void);
void srand(int NewSeed);

#endif
