/****************************************************************************************************************
 * Filename           : bsp_led.h
 * Description        : Header file for bsp_led.c
****************************************************************************************************************/

/* Define to prevent recursive inclusion ----------------------------------------------------------------------*/
#ifndef __BSP_LED_H
#define __BSP_LED_H



/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "bsp_nixieTube.h"

/* Exported constants -----------------------------------------------------------------------------------------*/
/* Exported macro ---------------------------------------------------------------------------------------------*/
#define FLOOR1_LED_PORT  GPIOB
#define FLOOR1_LED_PIN   GPIO_Pin_0

#define FLOOR2_LED_PORT  GPIOB
#define FLOOR2_LED_PIN   GPIO_Pin_1

#define FLOOR3_LED_PORT  GPIOB
#define FLOOR3_LED_PIN   GPIO_Pin_2

#define FLOOR4_LED_PORT  GPIOB
#define FLOOR4_LED_PIN   GPIO_Pin_3

#define FLOOR5_LED_PORT  GPIOB
#define FLOOR5_LED_PIN   GPIO_Pin_4

#define FLOOR6_LED_PORT  GPIOB
#define FLOOR6_LED_PIN   GPIO_Pin_5

#define FLOOR7_LED_PORT  GPIOB
#define FLOOR7_LED_PIN   GPIO_Pin_6

#define DIR_LED_PORT     GPIOB
#define DIR_LED_PIN      GPIO_Pin_15

#define UP_LED_PORT      GPIOB
#define UP_LED_PIN       GPIO_Pin_7

#define DOWN_LED_PORT    GPIOC
#define DOWN_LED_PIN     GPIO_Pin_13



/* Exported types ---------------------------------------------------------------------------------------------*/
/* List of LEDs                                                                                                */ 
typedef enum
{
  FLOOR1_LED = 0, 
  FLOOR2_LED = 1, 
  FLOOR3_LED = 2, 
  FLOOR4_LED = 3, 
  FLOOR5_LED = 4, 
  FLOOR6_LED = 5, 
  FLOOR7_LED = 6, 
  DIR_LED    = 7,
  UP_LED     = 8,
  DOWN_LED   = 9
}LED_NameTypeDef;

/* Status of LED                                                                                               */
typedef enum
{
  LED_ON  = 0,
  LED_OFF = 1
}LED_StatusTypeDef;

typedef struct 
{
  LED_NameTypeDef   LedName;         /* LED Name                                                             */
  GPIO_TypeDef*     LedPort;         /* The Port the LED in                                                  */
  const uint16_t    LedPin;          /* The Pin the LED in                                                   */
  LED_StatusTypeDef LedInitStatus;   /* Initial status of the LED                                            */
}LED_InitTypeDef;

/* Exported functions -----------------------------------------------------------------------------------------*/
extern void bsp_LedInit(void);
extern void bsp_LedDirUp(void);
extern void bsp_LedDirDown(void);
extern void bsp_LedDirNone(void);
extern void bsp_LedDispFloorNone(void);
extern void bsp_LedDispFloor(FLOOR_NumTypeDef floorNum);

/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
}
#endif    /* __cplusplus                                                                                       */

#endif    /* __BSP_LED_H                                                                                       */
/*************************************************END OF FILE***************************************************/



