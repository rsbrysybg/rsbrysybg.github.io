#ifndef __MY_ACTION_H
#define __MY_ACTION_H

#include "main.h"

void ACTION(void);

#endif /* __MY_ACTION_H */
