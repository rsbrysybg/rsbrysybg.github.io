#include "stm32f10x.h"
#include "sys.h"
#include "delay.h"
#include "project.h"
#include "LCD1602.h"
#include "adc.h"
#include "LORA.h"
#include "key.h"
#include "lcd_task.h"
#include "lora_task.h"

void __init_gpio(void)
{		

	NVIC_PriorityGroupConfig(2);
	Delay_init ( );
	KEY_NVIC_Config (  );
	LCD_INIT();
	FJ_GPIO_Init();
	ADC_Config();
	Lora_Config();
	LCD_WRITE_StrDATA("TYDZKJ",0,4);
	MQ_Packet.AD_MAX=1.00;
	Delay_ms(5000);
}

int main(void)
{
	__init_gpio();
	while (1)
	{
	delay_ms(500);
	MQ_2_TASK ();
	Lora_TX_TASK ();
	LCD_TASK();
	}
}

