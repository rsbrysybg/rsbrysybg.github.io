#ifndef __ADC_H__
#define __ADC_H__

#include "project.h"
#include "mq_task.h"

void ADC_Config (void);
float ADC_GetValue(void);

#endif /*__ADC_H__*/



