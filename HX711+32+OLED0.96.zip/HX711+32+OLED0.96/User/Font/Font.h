#ifndef __FONT_H
#define	__FONT_H

#include "stm32f10x.h"

extern unsigned char F16x16[];
extern unsigned char F6x8[][6];
extern unsigned char F8X16[];
extern unsigned char BMP1[];

#endif

