/************************************************************************************************************************
 * Filename           : bsp_button.h
 * Description        : Header file for bsp_button.c
*************************************************************************************************************************/

/* Define to prevent recursive inclusion -----------------------------------------------------------------------*/
#ifndef __BSP_BUTTON_H
#define __BSP_BUTTON_H



/* Export C interface if this file used by C++ source code                                                      */

/* Includes ----------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported constants ------------------------------------------------------------------------------------------*/
/* Exported macro ----------------------------------------------------------------------------------------------*/
#define BUTTON0_PORT        GPIOA
#define BUTTON0_PIN         GPIO_Pin_0

#define BUTTON1_PORT        GPIOA
#define BUTTON1_PIN         GPIO_Pin_1

#define BUTTON2_PORT        GPIOA
#define BUTTON2_PIN         GPIO_Pin_2

#define BUTTON3_PORT        GPIOA
#define BUTTON3_PIN         GPIO_Pin_3

#define BUTTON4_PORT        GPIOA
#define BUTTON4_PIN         GPIO_Pin_4

#define BUTTON5_PORT        GPIOA
#define BUTTON5_PIN         GPIO_Pin_5

#define BUTTON6_PORT        GPIOA
#define BUTTON6_PIN         GPIO_Pin_6

#define BUTTON7_PORT        GPIOA
#define BUTTON7_PIN         GPIO_Pin_7

#define BUTTON_DPRESS           1
#define BUTTON_UP               0

/* (scan time * BUTTON_LONG_CLICK_TIME) = actual time                                                           */
#define BUTTON_LONG_CLICK_TIME  100      /* Notice : the value of this can not over sizeof(s_timeCount)         */
#define BUTTON_SCAN_TIME        10       /* 10ms                                            */

/* Exported types ----------------------------------------------------------------------------------------------*/
/* Define the name of each button                                                                               */
typedef enum
{
  USER_BUTTON0 = 0,
  USER_BUTTON1 = 1,
  USER_BUTTON2 = 2,
  USER_BUTTON3 = 3,
  USER_BUTTON4 = 4,
  USER_BUTTON5 = 5,
  USER_BUTTON6 = 6,
  USER_BUTTON7 = 7,
  USER_BUT_NUM = 8,
}BUTTON_IDTypeDef;

/* Events of a button                                                                                           */
typedef enum
{
  BUTTON_NONE_CLICK   = 0,                /* No event in a button                                             */
  BUTTON_SINGLE_CLICK = 1,                /* Button single click event occur                                  */
  BUTTON_DOUBLE_CLICK = 2,                /* Button double click event occur                                  */
  BUTTON_LONG_CLICK   = 3                 /* Button long   click event occur                                  */
}BUTTON_EventTypeDef;


/* Button initialization structure                                                                              */
typedef struct
{
  BUTTON_IDTypeDef buttonName;
  GPIO_TypeDef*    buttonPort;
  uint16_t         buttonPin ;
}BUTTON_InitTypeDef;


typedef enum
{
  DETECT_STATE0 = 0,
  DETECT_STATE1 = 1,
  DETECT_STATE2 = 2,
  DETECT_STATE3 = 3
}BUTTON_DetectTypeDef;
  
typedef enum
{
  SCAN_STATE0 = 0,
  SCAN_STATE1 = 1,
}BUTTON_ScanTypeDef;
  

/* Define for specific operation of button(each button correspond with one of this)                            */
typedef struct 
{   
  BUTTON_IDTypeDef buttonName;            /* The name of the button */
  BUTTON_DetectTypeDef detState;          /* Current detect state of th button*/                                     
  BUTTON_ScanTypeDef   scanState;         /* Current scan state of th button*/  
  uint32_t longTimeCount;                 /* Use to record the time in long press detecttion*/ 
  uint32_t doubleTimeCount;               /* Use to record the time in double press detecttion*/ 
}BUTTON_TypeDef;


typedef struct 
{
  uint32_t timeCounter;
  bool     counterFlag;
  BUTTON_TypeDef buttonArr[USER_BUT_NUM];
}BUTTON_MANAGE_TypeDef;

    
extern BUTTON_MANAGE_TypeDef g_button;

/* Exported functions ------------------------------------------------------------------------------------------*/
extern void bsp_ButtonInit(void);
extern void bsp_ButtonScan(void);
extern void app_AdjustElevatorDispatch(BUTTON_IDTypeDef btName, BUTTON_EventTypeDef btEvent);

                                                                  

#endif   /* __BSP_BUTTON_H                                                                                      */

/*************************************************END OF FILE****************************************************/



