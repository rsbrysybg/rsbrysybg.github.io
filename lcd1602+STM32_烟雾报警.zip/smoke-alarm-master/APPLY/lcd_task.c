#include "lcd_task.h"
/**
  * @brief 	LCD��ʾ����
  * @param  None
  * @retval None
  */
void LCD_TASK ( void )
{
		uint8_t My_buf[10];
		LCD_WRITE_CMD( 0x01 );
		memset(My_buf, 0x00, 10);
		sprintf((char *)My_buf, "%0.2f",MQ_Packet.AD_Value);
		LCD_WRITE_StrDATA("machine:",0,0);
		LCD_WRITE_StrDATA(My_buf,0,11);
		LCD_WRITE_StrDATA("V:",0,15);	
		if(MQ_Packet.Lora_trigger==1||Lora_Packet.RX_Buf[1]==1)
		{
						
			memset(My_buf, 0x00, 10);
			if(MQ_Packet.Lora_trigger==1)
			{
				sprintf((char *)My_buf, "%d",Lora_Packet.TX_Buf[0]);
				RELAY_ON();
			}
			else if(Lora_Packet.RX_Buf[1]==1)
			{
				sprintf((char *)My_buf, "%d",Lora_Packet.RX_Buf[0]);
			}
			LCD_WRITE_StrDATA("warning:",1,0);
			LCD_WRITE_StrDATA(My_buf,1,8);
			FMQ_ON();			
			Lora_Packet.RX_Buf[1]=0; 
		}
		else
		{
			FMQ_OFF();
			RELAY_OFF();
		}
}
