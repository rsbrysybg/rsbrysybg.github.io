#ifndef __KEY_H__
#define __KEY_H__

#include "sys.h"
#include "project.h"
#include "delay.h"
#include "key_task.h"



void KEY_NVIC_Config ( void );

#endif /*__KEY_H__ */


