/************************************************************************************************************************
 * Filename           : bsp_buzzer.c
 * Description        : Buzzer driver function file
*************************************************************************************************************************/
/* Includes ---------------------------------------------------------------------------------------------------*/
#include "bsp_buzzer.h"

/* Private typedef --------------------------------------------------------------------------------------------*/
/* Private define ---------------------------------------------------------------------------------------------*/
/* Private macro ----------------------------------------------------------------------------------------------*/
/* Private variables ------------------------------------------------------------------------------------------*/
uint32_t g_buzzerTimeCounter;


/* Private function prototypes --------------------------------------------------------------------------------*/
static void bsp_BuzzerOn(void);
static void bsp_BuzzerOff(void);

/* Private functions ------------------------------------------------------------------------------------------*/


/**************************************************************************************************************
 * Function Name   : bsp_BuzzerInit
 * Description     : Configures Buzzer on GPIO
 * Input Variable  : None
 * Return Variable : None
***************************************************************************************************************/
void bsp_BuzzerInit(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  
  GPIO_InitStructure.GPIO_Pin   = BUZZER_PIN;                
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;       
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(BUZZER_PORT,&GPIO_InitStructure);

  g_buzzerTimeCounter = 0;
  bsp_BuzzerOff();
}


/**************************************************************************************************************
 * Function Name   : bsp_BuzzerControl 
 * Description     : Control the buzzer
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_BuzzerControl(void)
{
   if (g_buzzerTimeCounter > 0)
   {
      bsp_BuzzerOn();
   }
   else
   {
      bsp_BuzzerOff();
   }
}

/**************************************************************************************************************
 * Function Name   : bsp_BuzzerEnable
 * Description     : Enable the buzzer
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_BuzzerEnable(void)
{
  g_buzzerTimeCounter = BUZZER_ENABLE_TIME;
}


/**************************************************************************************************************
 * Function Name   : bsp_BuzzerOn
 * Description     : Turn on a specific Buzzer
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
static void bsp_BuzzerOn(void)
{
  BUZZER_PORT->BSRR |= (uint32_t)BUZZER_PIN;
  BUZZER_PORT->BSRR &= !((uint32_t)BUZZER_PIN << 16);
}


/***************************************************************************************************************
 * Function Name   : bsp_BuzzerOff
 * Description     : Turn off Buzzer
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
static void bsp_BuzzerOff(void)
{
  BUZZER_PORT->BSRR |= BUZZER_PIN << 16;
  BUZZER_PORT->BSRR &= !(uint32_t)BUZZER_PIN;
}


/*************************************************END OF FILE***************************************************/



