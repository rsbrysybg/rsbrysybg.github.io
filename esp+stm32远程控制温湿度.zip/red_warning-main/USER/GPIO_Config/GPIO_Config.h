#ifndef _GPIO_Config_h_
#define _GPIO_Config_h_
#include"stm32f10x.h"
void GPIO_Config(void);
#endif

