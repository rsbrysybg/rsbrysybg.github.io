#ifndef __PROJECT_H__
#define __PROJECT_H__

#include "stm32f10x.h"
#include "sys.h"

//LCD1602���Ŷ���GPIOC
#define LCD_RS		GPIO_Pin_8	
#define	LCD_RW		GPIO_Pin_9
#define	LCD_EN		GPIO_Pin_10
#define LCD_DB		GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10| GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15
#define LCD_D7		GPIO_Pin_15

//���������Ŷ���GPIOC
#define	FMQ_Pin		GPIO_Pin_1
#define FMQ_ON()	GPIO_ResetBits(GPIOC,FMQ_Pin)
#define FMQ_OFF()	GPIO_SetBits(GPIOC,FMQ_Pin)

//�̵�������GPIOC
#define	RELAY_Pin		GPIO_Pin_0
#define RELAY_ON()	GPIO_ResetBits(GPIOC,RELAY_Pin)
#define	RELAY_OFF()	GPIO_SetBits(GPIOC,RELAY_Pin)

//ADC��������
#define ADC_PIN  				GPIO_Pin_2
#define ADC_CLK     		RCC_APB2Periph_ADC2
#define Sensor_ADC      ADC2
#define ADC_CHANNEL   	ADC_Channel_12

//E220��������
#define Lora_AUX_Pin		GPIO_Pin_4

#define Lora_TX_Pin			GPIO_Pin_3
#define Lora_RX_Pin			GPIO_Pin_2
#define Lora_M1_Pin			GPIO_Pin_1
#define Lora_M0_Pin			GPIO_Pin_0
#define Lora_USART			USART2
#define	Lora_GPIO				GPIOA

//KEY���Ŷ���
#define Key1		GPIO_Pin_4
#define Key2		GPIO_Pin_5
#define Key3		GPIO_Pin_6


void FJ_GPIO_Init	(void);


#endif /* __PROJECT_H__*/


