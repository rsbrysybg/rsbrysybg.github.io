/****************************************************************************************************************
 * Filename           : bsp_buzzer.h
 * Description        : Header file for bsp_buzzer.c
****************************************************************************************************************/

/* Define to prevent recursive inclusion ----------------------------------------------------------------------*/
#ifndef __BSP_BUZZER_H
#define __BSP_BUZZER_H



/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported macro ---------------------------------------------------------------------------------------------*/
#define BUZZER_ENABLE_TIME    1000  /* 1s */

#define BUZZER_PORT  GPIOC
#define BUZZER_PIN   GPIO_Pin_14

/* Exported types ---------------------------------------------------------------------------------------------*/

/* Exported constants -----------------------------------------------------------------------------------------*/
extern uint32_t g_buzzerTimeCounter;

/* Exported functions -----------------------------------------------------------------------------------------*/
extern void bsp_BuzzerInit(void);
extern void bsp_BuzzerEnable(void);
extern void bsp_BuzzerControl(void);

/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
}
#endif    /* __cplusplus                                                                                       */

#endif    /* __BSP_BUZZER_H                                                                                      */

/***********************************************  END OF FILE  *************************************************/






