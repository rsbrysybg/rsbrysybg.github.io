#ifndef _EXTI_Config_h_
#define _EXTI_Config_h_
#include"stm32f10x.h"
void EXTI_Config(void);
void EXTI_GPIO_Config(void);
void EXTI_NVIC_Config(void);
void EXTI_INIT(void);
#endif

