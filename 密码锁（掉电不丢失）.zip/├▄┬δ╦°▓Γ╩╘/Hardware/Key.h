#ifndef __KEY_H
#define __KEY_H

void Key_Init_A(void);
void Key_Init_B(void);
uint8_t Key_GetNum(void);

#endif
