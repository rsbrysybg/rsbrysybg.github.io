#ifndef _RCC_H
#define _RCC_H
#include "stm32f10x.h"

#define MCO_GPIO_CLK		RCC_APB2Periph_GPIOA
#define MCO_GPIO_PIN		GPIO_Pin_8
#define MCO_GPIO_PORT		GPIOA

void RCCCLOCK_Init(void);
void MCO_GPIO_Init(void);
#endif

