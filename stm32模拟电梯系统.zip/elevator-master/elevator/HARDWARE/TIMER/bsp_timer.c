/*************************************************************************************************************
 * Filename           : bsp_timer.c
 * Description        : Timer driver function file
*************************************************************************************************************/


/* Includes ------------------------------------------------------------------------------------------------*/
#include "bsp_timer.h"

/* Private typedef -----------------------------------------------------------------------------------------*/
/* Private define ------------------------------------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------------------------------------*/
static void bsp_Tim2NvicConfiguration(void);

/* Private functions ---------------------------------------------------------------------------------------*/





/************************************************************************************************************
 * Function Name   : bsp_TimerInit
 * Description     : Configures Timer as a time base
 * Input Variable  : void 
 * Return Variable : None
*************************************************************************************************************/
void bsp_TimerInit(void)
{
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  
  bsp_Tim2NvicConfiguration();
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  TIM_DeInit(TIM2);
  TIM_TimeBaseStructure.TIM_Period      =  1000-1;	        /* Reload in 1ms                            */ 
  TIM_TimeBaseStructure.TIM_Prescaler   = (72 - 1);	        /* System frequency predivider 72M / 72     */     
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; /* Counter direction (Up)                   */
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  TIM_ClearFlag(TIM2, TIM_FLAG_Update);	                    /* Clear interrupt flag                     */
  TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
  TIM_Cmd(TIM2, ENABLE);	                                    /* Enable timer clock                       */ 
}


/************************************************************************************************************
 * Function Name   : bsp_Tim2NvicConfiguration
 * Description     : Configures Timer as a time base
 * Input Variable  : void 
 * Return Variable : None
*************************************************************************************************************/
static void bsp_Tim2NvicConfiguration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure; 

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);  													
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;	  
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}



/*************************************************END OF FILE************************************************/



