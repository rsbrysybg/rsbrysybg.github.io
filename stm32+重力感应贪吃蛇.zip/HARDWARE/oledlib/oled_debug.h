#ifndef OLED_DEBUG_H
#define OLED_DEBUG_H

int OledPrintf(const char *str,...);

#endif

