#include "delay.h"
void delay_ms(u32 t)
{
	for(;t>0;t--)
	{	int i;
		for(i=1000;i>0;i--)
		{__nop();__nop();}
	}
}

void delay_10us(u32 t)
{
	for(;t>0;t--)
	{	int i;
		for(i=10;i>0;i--)
		{__nop();__nop();}
	}
}
