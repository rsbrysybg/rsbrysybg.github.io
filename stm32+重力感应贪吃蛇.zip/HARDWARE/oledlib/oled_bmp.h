#ifndef OLED_BMP_H
#define OLED_BMP_H
extern const unsigned char BmpTest1[];
extern const unsigned char BmpTest2[];
extern const unsigned char BmpTest3[];
extern const unsigned char DZTBGZ[];
extern const unsigned char TempLogo[];
extern const unsigned char coin[];
extern const unsigned char wenzi[];
extern const unsigned char over[];
extern const unsigned char snake[];
#endif

