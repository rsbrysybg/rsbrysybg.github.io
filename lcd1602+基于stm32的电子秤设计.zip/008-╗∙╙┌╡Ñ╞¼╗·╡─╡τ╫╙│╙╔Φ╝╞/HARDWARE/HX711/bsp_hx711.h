#ifndef __BSP_HX711_H
#define __BSP_HX711_H

/************************* ͷ�ļ� *************************/
#include "stm32f10x.h"

/************************* �궨�� *************************/
#define HX711_DOUT_PORT         GPIOB
#define HX711_DOUT_CLK          RCC_APB2Periph_GPIOB
#define HX711_DOUT_PIN          GPIO_Pin_0

#define HX711_SCK_PORT         GPIOB
#define HX711_SCK_CLK          RCC_APB2Periph_GPIOB
#define HX711_SCK_PIN          GPIO_Pin_1



/************************* �������� *************************/
void HX711_GPIO_Config(void);
uint32_t HX711_Read(void);
uint32_t HX711_GetInitialWeight(void);

#endif /* __BSP_HX711_H */
