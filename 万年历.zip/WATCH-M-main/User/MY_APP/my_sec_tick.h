#ifndef __MY_SEC_TICK_H
#define __MY_SEC_TICK_H

#include "stm32f10x.h"
#include "main.h"




void MIAOBIAO(void);











#endif /* __MY_SEC_TICK_H */
