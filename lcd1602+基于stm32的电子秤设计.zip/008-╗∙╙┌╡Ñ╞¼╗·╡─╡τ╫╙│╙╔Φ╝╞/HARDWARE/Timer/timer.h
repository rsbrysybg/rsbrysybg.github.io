
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _TIMER_H_
#define _TIMER_H_
  
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

void TIM3_Init(u16 arr,u16 psc); 
// 
#endif
