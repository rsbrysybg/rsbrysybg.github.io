/****************************************************************************************************************
 * Filename           : bsp_nixieTube.h
 * Description        : Header file for bsp_nixieTube.c
****************************************************************************************************************/

/* Define to prevent recursive inclusion ----------------------------------------------------------------------*/
#ifndef __BSP_NIXIE_TUBE_H
#define __BSP_NIXIE_TUBE_H



/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported constants -----------------------------------------------------------------------------------------*/
#define FLOOR_NUM     7            /* The highest defined floor number  */

/* Exported macro ---------------------------------------------------------------------------------------------*/
#define NIXIE_TUBE1_PORT  GPIOB
#define NIXIE_TUBE1_PIN   GPIO_Pin_8

#define NIXIE_TUBE2_PORT  GPIOB
#define NIXIE_TUBE2_PIN   GPIO_Pin_9

#define NIXIE_TUBE3_PORT  GPIOB
#define NIXIE_TUBE3_PIN   GPIO_Pin_10

#define NIXIE_TUBE4_PORT  GPIOB
#define NIXIE_TUBE4_PIN   GPIO_Pin_11

#define NIXIE_TUBE5_PORT  GPIOB
#define NIXIE_TUBE5_PIN   GPIO_Pin_12

#define NIXIE_TUBE6_PORT  GPIOB
#define NIXIE_TUBE6_PIN   GPIO_Pin_13

#define NIXIE_TUBE7_PORT  GPIOB
#define NIXIE_TUBE7_PIN   GPIO_Pin_14



/* Exported types ---------------------------------------------------------------------------------------------*/
/* List of NIXIE_TUBE LEDs                                                                                                */ 
typedef enum
{
  NIXIE_TUBE1_LED = 0, 
  NIXIE_TUBE2_LED = 1, 
  NIXIE_TUBE3_LED = 2, 
  NIXIE_TUBE4_LED = 3, 
  NIXIE_TUBE5_LED = 4, 
  NIXIE_TUBE6_LED = 5, 
  NIXIE_TUBE7_LED = 6, 
}NIXIE_TUBE_NameTypeDef;

typedef enum
{
  NIXIE_TUBE_FLOOR1 = 0x06,
  NIXIE_TUBE_FLOOR2 = 0x5b,
  NIXIE_TUBE_FLOOR3 = 0x4f,
  NIXIE_TUBE_FLOOR4 = 0x66,
  NIXIE_TUBE_FLOOR5 = 0x6d,
  NIXIE_TUBE_FLOOR6 = 0x7d,
  NIXIE_TUBE_FLOOR7 = 0x07,
}NIXIE_TUBE_FLOOR_NUM_TypeDef;

typedef enum
{
  FLOOR1 = 1,
  FLOOR2 = 2,    
  FLOOR3 = 3,
  FLOOR4 = 4,   
  FLOOR5 = 5,
  FLOOR6 = 6,   
  FLOOR7 = 7,
}FLOOR_NumTypeDef;

/* Status of NIXIE_TUBE                                                                                               */
typedef enum
{
  NIXIE_TUBE_ON  = 0,
  NIXIE_TUBE_OFF = 1
}NIXIE_TUBE_StatusTypeDef;

typedef struct 
{
  NIXIE_TUBE_NameTypeDef NixieTubeName;         /* NixieTube Name                                                             */
  GPIO_TypeDef*     NixieTubePort;         /* The Port the NixieTube in                                                  */
  const uint16_t    NixieTubePin;          /* The Pin the NixieTube in                                                   */
  NIXIE_TUBE_StatusTypeDef NixieTubeInitStatus;   /* Initial status of the NixieTube */
}NIXIE_TUBE_InitTypeDef;

/* Exported functions -----------------------------------------------------------------------------------------*/
extern void bsp_LixieTubeInit(void);
extern void bsp_NixieTubeDisplayFloor(FLOOR_NumTypeDef floorNum);

/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
}
#endif    /* __cplusplus                                                                                       */

#endif    /* __BSP_NIXIE_TUBE_H                                                                                      */
/***********************************************  END OF FILE  *************************************************/




