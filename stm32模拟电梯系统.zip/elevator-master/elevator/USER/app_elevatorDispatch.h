/* Define to prevent recursive inclusion ----------------------------------------------------------------------*/
#ifndef __APP_FLOOR_DISPATCH_H
#define __APP_FLOOR_DISPATCH_H


/* Export C interface if this file used by C++ source code                                                      */
#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "bsp_button.h"
#include "bsp_nixieTube.h"



/* Exported macro ---------------------------------------------------------------------------------------------*/
#define ELEVATOR_STOP_TIME      3000     /* When the elevator arrive at the floor, it will stop for 3s */

/* Exported types ---------------------------------------------------------------------------------------------*/
typedef enum
{
  ELEVATOR_DIR_NONE = 0,
  ELEVATOR_DIR_UP   = 1,
  ELEVATOR_DIR_DOWN = 2,
}ELEVATOR_DirTypeDef;


typedef struct
{
  uint8_t pressedNum;
  uint16_t stopTimeCounter;
  uint8_t dispatchArr[FLOOR_NUM];
  ELEVATOR_DirTypeDef curDir;
  FLOOR_NumTypeDef    curFloor;
}FLOOR_DispatchTypeDef;

/* Exported constants -----------------------------------------------------------------------------------------*/
extern FLOOR_DispatchTypeDef g_elevatorDispatch;

/* Exported functions -----------------------------------------------------------------------------------------*/
extern void app_BspInit(void);
extern void app_ElevatorDispatch(void);
extern void app_AdjustElevatorDispatch(BUTTON_IDTypeDef btName, BUTTON_EventTypeDef btEvent);


#ifdef __cplusplus
}
#endif    /* __cplusplus                                                                                       */

#endif    /* __APP_FLOOR_DISPATCH_H                                                                            */

/*************************************************END OF FILE***************************************************/



