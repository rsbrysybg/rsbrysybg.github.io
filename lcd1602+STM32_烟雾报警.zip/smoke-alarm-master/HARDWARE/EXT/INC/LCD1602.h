#ifndef	__LCD1602_H__
#define	__LCD1602_H__

#include "project.h"
#include "delay.h"

void LCD_INIT(void);
void LCD_WRITE_CMD( int CMD );
void ReadBusy(void);
void LCD_WRITE_StrDATA( unsigned char *StrData, unsigned char row, unsigned char col );

#endif/*__LCD1602_H__*/


