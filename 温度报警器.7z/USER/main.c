#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "ds18b20.h" 
#include "beep.h"
#include "timer.h"

u8 a=0;
u8 senddata[]="Temp xx.x--";
void SendTemp() //��Ƭ����pc�����¶ȼ�������  
{ 
	  u8 n=0;
	  senddata[5]=DS18B20_Get_Temp()/100+'0';
	  senddata[6]=(DS18B20_Get_Temp()%100)/10+'0';
	  senddata[8]=DS18B20_Get_Temp()%10+'0';
	  for(n=0;n<=9;n++)
	  {
		USART_SendData(USART1,senddata[n]);
		while((USART_GetFlagStatus(USART1,USART_FLAG_TC))!=SET);
	  }
		a=0;
}	

 int main(void)
 {
	u8 t=0;	
	short temperature;    	   
  BEEP_Init();
	delay_init();	    	   
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 	
	LED_Init();		  		
	LCD_Init();			   	
  TIM3_Int_Init(9999,7199);	
	 
 	POINT_COLOR=BLACK;		
	LCD_ShowString(30,70,300,16,16,"DS18B20 Temperature experimment");
	LCD_ShowString(30,90,200,16,16,"wang han ren");	
	LCD_ShowString(30,110,200,16,16,"1962510217");	
	LCD_ShowString(30,130,200,16,16,"2022/4/10");
	 
 	while(DS18B20_Init())	//DS18B20��ʼ��	
	{
		LCD_ShowString(30,130,200,16,16,"DS18B20 Error");
		delay_ms(200);
		LCD_Fill(30,130,239,130+16,WHITE);
 		delay_ms(200);
	}								   

	POINT_COLOR=BLUE;//��������Ϊ��ɫ 
 	LCD_ShowString(30,150,200,16,16,"Temp:   . C");	 
	
	while(1)
	{	
		
 		if(t%10==0)			//ÿ100ms��ȡһ��
		{									  
			temperature=DS18B20_Get_Temp();
			if(temperature<0)
			{
				LCD_ShowChar(30+40,150,'-',16,0);			
				temperature=-temperature;					
			}else LCD_ShowChar(30+40,150,' ',16,0);		
			  LCD_ShowNum(30+40+8,150,temperature/10,2,16);		    
   			LCD_ShowNum(30+40+32,150,temperature%10,1,16);		   
		}	
		
    if(DS18B20_Get_Temp()>=300)
		{				 
				BEEP=1;
				LCD_ShowString(30,170,300,16,16,"Temperature out of range");
		}
		else 
		{
		  BEEP=0;
			LCD_ShowString(30,170,300,16,16,"Temperature is normal    ");
		}	
		
		if(a==1)
	  SendTemp();
		
	}
}

