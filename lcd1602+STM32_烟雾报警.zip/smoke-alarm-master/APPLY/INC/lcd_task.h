#ifndef __LCD_TASK_H__
#define __LCD_TASK_H__

#include "delay.h"
#include "sys.h"
#include "project.h"
#include "LCD1602.h"
#include "mq_task.h"
#include <stdio.h>
#include <string.h>
#include "lora.h"
void LCD_TASK ( void );

#endif /* __LCD_TASK_H__*/


