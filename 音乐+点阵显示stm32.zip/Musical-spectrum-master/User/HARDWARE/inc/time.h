#ifndef _TIME_H
#define _TIME_H

  #include "stm32f10x.h"

  void TIM3_Init(u16 arr,u16 psc);

#endif












