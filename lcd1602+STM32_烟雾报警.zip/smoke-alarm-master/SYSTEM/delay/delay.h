#ifndef __DELAY_H
#define __DELAY_H


#include "stm32f10x.h"


void Delay_init ( void );
void Delay_ms (u16 x);
void delay_ms ( u32 n_ms );
void delay_us ( u16 n_us );

#endif



