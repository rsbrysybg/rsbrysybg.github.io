#ifndef _public_h_
#define _public_h_
#include "stm32f10x.h"   //stm32ͷ�ļ�
#include "GPIO_Config.h"  //GPIO�ܽ�����
#include "EXTI_Config.h"   //EXTI����
#include "NVIC_Config.h"   //NVIC����
#include "interface.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>
#include "esp8266.h"
#include "onenet.h"
#include "esp8266_send.h"

#endif

