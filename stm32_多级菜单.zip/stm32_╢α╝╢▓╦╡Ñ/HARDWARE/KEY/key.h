#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

#define KEY1 PAin(1)
#define KEY2 PAin(2)
#define KEY3 PAin(3)

void KEY_Init(void);//��ʼ��

		 				    
#endif
