#include "adc.h"
/**
  * @brief  ADC_gpio��ʼ��
  * @param  None
  * @retval None
  */
static void ADC_GPIO_Init (void)
{
	GPIO_InitTypeDef GPIOC_InitStruct;
	
	RCC_APB2PeriphClockCmd ( RCC_APB2Periph_GPIOC, ENABLE );
	GPIOC_InitStruct.GPIO_Pin = ADC_PIN;
	GPIOC_InitStruct.GPIO_Mode = GPIO_Mode_AIN;	
	
	GPIO_Init(GPIOC, &GPIOC_InitStruct);	
}

/**
  * @brief  ADC��ʼ������
  * @param  None
  * @retval None
  */
void ADC_Config (void)
{
	ADC_InitTypeDef ADC_InitStruct;
	
	ADC_GPIO_Init();
	ADC_DeInit(Sensor_ADC);
	RCC_APB2PeriphClockCmd ( ADC_CLK, ENABLE );
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);
	
	ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStruct.ADC_ScanConvMode = DISABLE;
	ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;	
	ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_NbrOfChannel = 1;
	
	ADC_Init(Sensor_ADC, &ADC_InitStruct);
	ADC_Cmd(Sensor_ADC, ENABLE);
	ADC_ResetCalibration(ADC1);	//ʹ�ܸ�λУ׼
	while(ADC_GetResetCalibrationStatus(Sensor_ADC));	//�ȴ���λУ׼����	
	ADC_StartCalibration(Sensor_ADC);
	while(ADC_GetCalibrationStatus(Sensor_ADC));// �ȴ�У׼���	
}

/**
  * @brief  ��ȡMQ��2������ĵ�ѹֵ
  * @param  None
  * @retval ADCֵ
  */
float ADC_GetValue(void)
{
	u16 adc_value = 0;
	u8 i = 0;
	
	for(i = 0; i < 50; i++)
	{ 
		ADC_RegularChannelConfig(Sensor_ADC, ADC_CHANNEL, 1, ADC_SampleTime_239Cycles5);
		//��ʼת��
		ADC_SoftwareStartConvCmd(Sensor_ADC,ENABLE);
		//ת���Ƿ����
		while(!ADC_GetFlagStatus(Sensor_ADC, ADC_FLAG_EOC ));//�ȴ�ת������
		adc_value = adc_value + ADC_GetConversionValue(Sensor_ADC);//��ADC�е�ֵ
	}
	adc_value=adc_value / 25;//ȡ��50�ε�ƽ��ֵ
	return (float)((adc_value/4096.00)*3.3);
}

