
#ifndef __ALL_INIT_H
#define __ALL_INIT_H


void all_init(void);



#endif


