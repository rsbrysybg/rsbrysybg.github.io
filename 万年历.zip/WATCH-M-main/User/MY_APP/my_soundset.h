#ifndef __MY_SOUNDSET_H
#define __MY_SOUNDSET_H

#include "main.h"


void SOUND(void);

#endif /* __MY_SOUNDSET_H */

