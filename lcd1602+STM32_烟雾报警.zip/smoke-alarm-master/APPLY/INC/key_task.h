#ifndef __KEY_TASK_H__
#define __KEY_TASK_H__

#include "delay.h"
#include "sys.h"
#include "project.h"

void KEY1_TASK (void);
void KEY2_TASK (void);
void KEY3_TASK (void);


#endif /* __KEY_TASK_H__*/


