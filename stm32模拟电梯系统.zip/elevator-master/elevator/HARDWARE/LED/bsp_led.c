/************************************************************************************************************************
 * Filename           : bsp_led.c
 * Description        : Led driver function file
*************************************************************************************************************************/


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "bsp_led.h"



/* Private typedef --------------------------------------------------------------------------------------------*/
/* Private define ---------------------------------------------------------------------------------------------*/
/* Private macro ----------------------------------------------------------------------------------------------*/
/* Private variables ------------------------------------------------------------------------------------------*/
LED_InitTypeDef g_ledInit[] = 
{
  {FLOOR1_LED,FLOOR1_LED_PORT,FLOOR1_LED_PIN,LED_OFF},  
  {FLOOR2_LED,FLOOR2_LED_PORT,FLOOR2_LED_PIN,LED_OFF}, 
  {FLOOR3_LED,FLOOR3_LED_PORT,FLOOR3_LED_PIN,LED_OFF}, 
  {FLOOR4_LED,FLOOR4_LED_PORT,FLOOR4_LED_PIN,LED_OFF}, 
  {FLOOR5_LED,FLOOR5_LED_PORT,FLOOR5_LED_PIN,LED_OFF}, 
  {FLOOR6_LED,FLOOR6_LED_PORT,FLOOR6_LED_PIN,LED_OFF}, 
  {FLOOR7_LED,FLOOR7_LED_PORT,FLOOR7_LED_PIN,LED_OFF}, 
  {DIR_LED   ,DIR_LED_PORT   ,DIR_LED_PIN   ,LED_OFF}, 
  {UP_LED    ,UP_LED_PORT    ,UP_LED_PIN    ,LED_OFF}, 
  {DOWN_LED  ,DOWN_LED_PORT  ,DOWN_LED_PIN  ,LED_OFF}, 
};

static int g_ledNumber = sizeof(g_ledInit) / sizeof(g_ledInit[0]);  /* The number of LEDs need to config       */

/* Private function prototypes --------------------------------------------------------------------------------*/
static void bsp_LedOn(LED_NameTypeDef ledName);
static void bsp_LedOff(LED_NameTypeDef ledName);
//static void bsp_LedToggle(LED_NameTypeDef ledName);


/* Private functions ------------------------------------------------------------------------------------------*/


/**************************************************************************************************************
 * Function Name   : bsp_LedInit
 * Description     : Configures LED on GPIO
 * Input Variable  : None
 * Return Variable : None
***************************************************************************************************************/
void bsp_LedInit(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  LED_NameTypeDef ledName;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE); /* Enable PB、PC,RCC_APB2Periph_AFIO Clock */ 
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);      /* Remapping GPIO_Remap_SWJ_Disable SWJ */
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE); /* Remapping GPIO_Remap_SWJ_JTAGDisable ，JTAG-DP Disable + SW-DP Enable*/

  for(ledName = g_ledInit[0].LedName;ledName < (LED_NameTypeDef)g_ledNumber;ledName++)
  {    
    GPIO_InitStructure.GPIO_Pin   = g_ledInit[ledName].LedPin;                
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(g_ledInit[ledName].LedPort, &GPIO_InitStructure);
    
    /* Set the led to its initial status                                                                  */
    if (g_ledInit[ledName].LedInitStatus == LED_ON)
    {
      bsp_LedOn(ledName);
    }
    else
    {
      bsp_LedOff(ledName);
    }
  }
}


/**************************************************************************************************************
 * Function Name   : bsp_LedOn
 * Description     : Turn off a specific led
 * Input Variable  : ledName
 * Return Variable : None
****************************************************************************************************************/
static void bsp_LedOn(LED_NameTypeDef ledName)
{
  g_ledInit[ledName].LedPort->BSRR |= (uint32_t)g_ledInit[ledName].LedPin << 16;
  g_ledInit[ledName].LedPort->BSRR &= !(uint32_t)g_ledInit[ledName].LedPin ;
}


/***************************************************************************************************************
 * Function Name   : bsp_LedOff
 * Description     : Turn on a specific led
 * Input Variable  : ledName
 * Return Variable : None
****************************************************************************************************************/
static void bsp_LedOff(LED_NameTypeDef ledName)
{
  g_ledInit[ledName].LedPort->BSRR |= (uint32_t)g_ledInit[ledName].LedPin ;
  g_ledInit[ledName].LedPort->BSRR &= !((uint32_t)g_ledInit[ledName].LedPin << 16);
}


#if 0
/*****************************************************************************************************************
 * Function Name   : bsp_LedToggle
 * Description     : Toggle a specific led
 * Input Variable  : ledName
*****************************************************************************************************************/
static void bsp_LedToggle(LED_NameTypeDef ledName)
{
  g_ledInit[ledName].LedPort->ODR ^= g_ledInit[ledName].LedPin;                                                                                              
}
#endif


/***************************************************************************************************************
 * Function Name   : bsp_LedDirUp
 * Description     : Display direction up in LED
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_LedDirUp(void)
{
  bsp_LedOn(UP_LED);
  bsp_LedOn(DIR_LED);
  bsp_LedOff(DOWN_LED);
}


/***************************************************************************************************************
 * Function Name   : bsp_LedDirDown
 * Description     : Display direction down in LED
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_LedDirDown(void)
{
  bsp_LedOff(UP_LED);
  bsp_LedOn(DIR_LED);
  bsp_LedOn(DOWN_LED);
}


/***************************************************************************************************************
 * Function Name   : bsp_LedDirNone
 * Description     : Display direction none
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_LedDirNone(void)
{
  bsp_LedOff(UP_LED);
  bsp_LedOff(DIR_LED);
  bsp_LedOff(DOWN_LED);
}


/***************************************************************************************************************
 * Function Name   : bsp_LedDispFloor
 * Description     : Display the floor information in floor led indicator
 * Input Variable  : floorNum : The number of floor to display in LED
 * Return Variable : None
****************************************************************************************************************/
void bsp_LedDispFloor(FLOOR_NumTypeDef floorNum)
{
  uint8_t i = 0;
  
  for (i = 0;i < FLOOR_NUM;i++)
  {
    if ((floorNum - 1) == (LED_NameTypeDef)i)
    {
      bsp_LedOn((LED_NameTypeDef)i);
    }
    else
    {
      bsp_LedOff((LED_NameTypeDef)i);
    }
  }
}


/***************************************************************************************************************
 * Function Name   : bsp_LedDispFloorNone
 * Description     : Not enable any the floor number LED
 * Input Variable  : None
 * Return Variable : None
****************************************************************************************************************/
void bsp_LedDispFloorNone(void)
{
  uint8_t i = 0;
  
  for (i = 0;i < FLOOR_NUM;i++)
  {
     bsp_LedOff((LED_NameTypeDef)i);
  }
}

/*************************************************END OF FILE***************************************************/


