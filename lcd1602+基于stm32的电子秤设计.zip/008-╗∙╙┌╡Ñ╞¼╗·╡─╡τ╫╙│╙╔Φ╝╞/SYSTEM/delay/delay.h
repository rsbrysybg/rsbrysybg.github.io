#ifndef __DELAY_H
#define __DELAY_H 			   
#include "sys.h"  

	 
void delay_ms(u32 t);
void delay_10us(u32 t);
#endif





























