#ifndef __KEYSCAN_EXTI_H
#define __KEYSCAN_EXTI_H 
#include "sys.h"

extern int flag;

void EXTIX_Init(void);//�ⲿ�жϳ�ʼ��	

#endif


