#ifndef __LED_H
#define __LED_H	 
#include "sys.h"


#define LED0 PAout(5)// PA5
#define LED1 PAout(6)// PA6	

void LED_Init(void);//��ʼ��


		 				    
#endif
