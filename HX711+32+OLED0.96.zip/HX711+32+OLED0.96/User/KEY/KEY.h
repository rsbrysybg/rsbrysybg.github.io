#ifndef __KEY_H
#define __KEY_H


#include "stm32f10x.h"

extern uint8_t Flag_Reset;   //��ͣ��־
extern uint8_t Flag_Calibration;   //����ת��־


//0X0078
#define KEY_Reset_PIN   				GPIO_Pin_4  		// 									GPIOB_Pin_4 0x0010 
#define KEY_Cali_PIN    				GPIO_Pin_5			//									GPIOB_Pin_5 0x0020
//#define KEY_CANCEL_PIN    		  GPIO_Pin_6			//									GPIOB_Pin_6 0x0040

#define KEY_Reset    					GPIO_ReadInputDataBit(GPIOA, KEY_Reset_PIN)
#define KEY_Calibration       GPIO_ReadInputDataBit(GPIOA, KEY_Cali_PIN)
//#define KEY_CANCEL  					GPIO_ReadInputDataBit(GPIOA, KEY_CANCEL_PIN)


extern uint16_t Key_Dat;

void Key_GPIO_Init(void);
void Scan_key(void);
	
#endif	

