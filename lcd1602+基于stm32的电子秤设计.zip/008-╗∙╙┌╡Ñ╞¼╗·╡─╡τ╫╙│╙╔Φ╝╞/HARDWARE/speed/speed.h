#ifndef _SPEED_H_
#define _SPEED_H_

#include "stm32f10x.h"

void Speed_Init(void);
void TIM1_Configuration(void);
void TIM2_Int_Init(u16 arr, u16 psc);
#endif

