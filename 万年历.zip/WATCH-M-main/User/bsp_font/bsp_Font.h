#ifndef __BSP_FONT_H
#define __BSP_FONT_H


extern unsigned char Char_16[][16];
extern unsigned char Char_8[][8];

extern unsigned char NUM[48][16];

extern unsigned char MAIN_MUNE[][128];
extern unsigned char SETTING_MUNE[][128];
extern unsigned char SOUND_MUNE[][128];

extern unsigned char DISPLAY_MUNE[][128];
extern unsigned char Turn[128];




#endif /* __BSP_FONT_H */
