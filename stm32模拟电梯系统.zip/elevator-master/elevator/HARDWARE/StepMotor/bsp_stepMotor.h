/****************************************************************************************************************
 * Filename           : bsp_stepMotor.h
 * Description        : Header file for bsp_stepMotor.c
****************************************************************************************************************/

/* Define to prevent recursive inclusion ----------------------------------------------------------------------*/
#ifndef __BSP_STEP_MOTOR_H
#define __BSP_STEP_MOTOR_H



/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
 extern "C" {
#endif


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "stm32f10x.h"

/* Exported constants -----------------------------------------------------------------------------------------*/
/* Exported macro ---------------------------------------------------------------------------------------------*/
#define STEP_MOTOR_A1_PORT  GPIOA
#define STEP_MOTOR_A1_PIN   GPIO_Pin_8

#define STEP_MOTOR_B1_PORT  GPIOA
#define STEP_MOTOR_B1_PIN   GPIO_Pin_9

#define STEP_MOTOR_C1_PORT  GPIOA
#define STEP_MOTOR_C1_PIN   GPIO_Pin_10

#define STEP_MOTOR_D1_PORT  GPIOA
#define STEP_MOTOR_D1_PIN   GPIO_Pin_11

#define STEP_MOTOR_COUNT_NUM 2          /* 2ms to change the level of the four pins connecting with the motor  */

#define FLOOR_MOTOR_ROUND_NUM 1000      /* The steps the motor will run at each floor                          */ 

/* Exported types ---------------------------------------------------------------------------------------------*/
/* List of STEP_MOTOR                                                                                               */ 
typedef enum
{
  STEP_MOTOR_A1 = 0, 
  STEP_MOTOR_B1 = 1, 
  STEP_MOTOR_C1 = 2, 
  STEP_MOTOR_D1 = 3, 
}STEP_MOTOR_NameTypeDef;


typedef struct 
{
  STEP_MOTOR_NameTypeDef stepMotorName;    /* stepMotor Name                                                   */
  GPIO_TypeDef*     stepMotorPort;         /* The Port the stepMotor in                                        */
  const uint16_t    stepMotorPin;          /* The Pin the stepMotor in                                         */
}STEP_MOTOR_InitTypeDef;

typedef enum
{
  STEP_MOTOR_STEP0 = 0,
  STEP_MOTOR_STEP1 = 1,    
  STEP_MOTOR_STEP2 = 2,
  STEP_MOTOR_STEP3 = 3, 
  STEP_MOTOR_STEP4 = 4, 
  STEP_MOTOR_WAIT  = 5,
}STEP_MOTOR_StepTypeDef;

typedef enum
{
  ELEVATOR_STOPPING = 0,
  ELEVATOR_RUNNING  = 1,
  ELEVATOR_ARRIVAL  = 2,
}ELEVATOR_StatusTypeDef;

typedef struct
{
  STEP_MOTOR_StepTypeDef curStep;  /* Record current step of the stepMotor when it turn around                 */
  STEP_MOTOR_StepTypeDef preStep;  /* Previous step      */
  ELEVATOR_StatusTypeDef status;
  uint8_t timeCounter;
  uint16_t loopNum;
}STEP_MOTOR_ControlTypeDef;


/* Exported variables -----------------------------------------------------------------------------------------*/
extern STEP_MOTOR_ControlTypeDef g_stepMotorControl;

/* Exported functions -----------------------------------------------------------------------------------------*/
extern void bsp_stepMotorUp(void);
extern void bsp_StepMotorInit(void);
extern void bsp_stepMotorDown(void);
extern void bsp_stepMotorEnable(void);
extern void bsp_stepMotorDisable(void);

/* Export C interface if this file used by C++ source code                                                     */
#ifdef __cplusplus
}
#endif    /* __cplusplus                                                                                       */

#endif    /* __BSP_STEP_MOTOR_H                                                                                      */

/***********************************************  END OF FILE  *************************************************/





