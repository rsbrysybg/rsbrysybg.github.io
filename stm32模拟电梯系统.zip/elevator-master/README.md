# elevator

#### 介绍
stm32模拟电梯系统

#### 软件架构
C语言+STM32F103c8

