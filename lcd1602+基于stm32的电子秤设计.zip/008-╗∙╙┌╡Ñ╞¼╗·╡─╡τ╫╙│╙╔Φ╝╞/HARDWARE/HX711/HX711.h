#ifndef _HX711_H_
#define _HX711_H_
#include "stm32f10x.h"
#include "delay.h"
#include "sys.h" 

#define ADSK PAout(15)			//����
#define ADDO PBin(5)			//����

unsigned long ReadCount(void);

#endif
