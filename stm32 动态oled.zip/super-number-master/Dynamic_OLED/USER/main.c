/************************************************************************* 
 ** Copyright.											 
 ** FileName: main.c								 
 ** Author: ���ں�:���һ��bug
 ** Data:2020-09-26 
 ** Description: dynamic��clock show demo
 ************************************************************************/
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "oled.h"
#include "timer.h"
#include "SuperNumber.h"

//һ�������Ӱ���8������
sSuperNum stSuperNum1;
sSuperNum stSuperNum2;
sSuperNum stSuperNum3;
sSuperNum stSuperNum4;
sSuperNum stSuperNum5;
sSuperNum stSuperNum6;
sSuperNum stSuperNum7;
sSuperNum stSuperNum8;

//��Ч״̬ת�Ʋ�ѯ��
uint8_t SegAction[MAX_SEG_STATUE][MAX_SEG_STATUE][SEG_NUM];

//��Ϊclock�ṩʱ��
uint8_t glTimer50msArriveFlag = 0;

void sDynamicClockInitial(void);
void sDynamicClockProcess(void);

 int main(void)
 {
	 
	delay_init();	    	   //��ʱ������ʼ��	  
	NVIC_Configuration();  //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	LED_Init();			       //LED�˿ڳ�ʼ��
  TIM3_Int_Init(490,7199);//10Khz�ļ���Ƶ�ʣ�������5000Ϊ500ms  
	OLED_Init();		    	 //��ʼ��OLED      
  OLED_Clear();          //��������
	OLED_ShowString(0,0,"->>2020-09-26<<-");	 
	 
  sDynamicClockInitial();
	
	while(1) 
	{		
		if(glTimer50msArriveFlag == 1)
		{
			 glTimer50msArriveFlag = 0;
			 sDynamicClockProcess();
		   LED0=!LED0;
		}
	}
}

/*************************************************************************
 ** Function Name:	sDynamicClockInitial		                               
 ** Purpose:		��ʼ��ʱ�ӵĸ�������β���   		        
 ** Params:															                              
 **	@ 	                                        			 
 ** Return:							  	 
 ** Notice:	  None.												 
 ** Author:		���ں�:���һ��bug											 
 *************************************************************************/
void sDynamicClockInitial(void)
{
	 #define NUM_OFFSET (19)
	
	uint16_t x_Location = 5;
	uint16_t y_Location = 20;
	
	stSuperNum1.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum1,x_Location,y_Location,10,10,2);
  InitialSegShowAction(&stSuperNum1,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET;

  stSuperNum2.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum2,x_Location,y_Location,10,10,2);
	InitialSegShowAction(&stSuperNum2,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET;
  stSuperNum3.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum3,x_Location,y_Location,2,10,2);
	InitialSegShowAction(&stSuperNum3,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET/2 + 2;
	stSuperNum4.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum4,x_Location,y_Location,10,10,2);
	InitialSegShowAction(&stSuperNum4,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET;
  stSuperNum5.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum5,x_Location,y_Location,10,10,2);
	InitialSegShowAction(&stSuperNum6,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET;
	stSuperNum6.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum6,x_Location,y_Location,2,10,2);
	InitialSegShowAction(&stSuperNum6,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET/2+2;
	stSuperNum7.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum7,x_Location,y_Location+10,5,5,2);
	InitialSegShowAction(&stSuperNum7,(uint8_t*)SegAction);

	x_Location += NUM_OFFSET/2+4;
	stSuperNum8.pDrawPoint = OLED_SetPixel;
	InitialSuperNum(&stSuperNum8,x_Location,y_Location+10,5,5,2);
	InitialSegShowAction(&stSuperNum8,(uint8_t*)SegAction);
	
}

/*************************************************************************
 ** Function Name:	sDynamicClockProcess		                               
 ** Purpose:		��̬ʱ�Ӵ���		        
 ** Params:															                              
 **	@ 	                                        			 
 ** Return:							  	 
 ** Notice:	  None.												 
 ** Author:		���ں�:���һ��bug											 
 *************************************************************************/
void sDynamicClockProcess(void)
{
  static timerCnt = 0;
	static uint16_t DPoint = 11;
	static uint16_t CurrHour = 23;  //��ǰСʱ
	static uint16_t CurrMin = 59;   //��ǰ����
	static uint16_t CurrSec = 50;   //��ǰs
	static uint16_t CurrSecOld = 0xFFFF;//�����s
	static uint16_t SecondPoint = 0;


////////////////////////////////////////////
	//ģ��ʱ��--�Ժ���Ի���������ʽ
	timerCnt++;
	if(timerCnt > 20) //50ms����1sһ��
	{
		timerCnt = 0;
		CurrSec++;
		if(CurrSec >= 60)
		{
			CurrSec = 0;
			CurrMin++;
			if(CurrMin >= 60)
			{
				CurrMin = 0;
				CurrHour++;
				if(CurrHour >= 24)
				{
					CurrHour = 0;
				}
			}
		}
	}
	////////////////////////////////////////
  //�����Ǹ�����ʾ����
	
		if(CurrSecOld != CurrSec)
		{
			if(CurrSecOld == 0xFFFF) //��ʾ������1s������
			{
			   CurrSecOld = 0xFFFE;
			}
			else 
			{
         CurrSecOld = CurrSec;//����
         DPoint = ((DPoint == 11)?(DPoint = 10):(DPoint = 11)); //����˸
			}
		}
			
		if(CurrSecOld < 60)
		{
		    SuperNumActionPlay(&stSuperNum1,(uint8_t*)SegAction,CurrHour/10);
		    SuperNumActionPlay(&stSuperNum2,(uint8_t*)SegAction,CurrHour%10);
		    SuperNumActionPlay(&stSuperNum3,(uint8_t*)SegAction,DPoint);
		    SuperNumActionPlay(&stSuperNum4,(uint8_t*)SegAction,CurrMin/10);
		    SuperNumActionPlay(&stSuperNum5,(uint8_t*)SegAction,CurrMin%10);
		    SuperNumActionPlay(&stSuperNum6,(uint8_t*)SegAction,DPoint);
		    SuperNumActionPlay(&stSuperNum7,(uint8_t*)SegAction,CurrSecOld/10);
		    SuperNumActionPlay(&stSuperNum8,(uint8_t*)SegAction,CurrSecOld%10);	
		}
		OLED_Refresh_Gram(); //ˢ��
}

