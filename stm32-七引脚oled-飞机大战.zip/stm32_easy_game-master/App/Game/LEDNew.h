#ifndef _LEDNEW_H_
#define _LEDNEW_H_

#include "DataType.h"

void LEDInit(void);
void LEDSet(u8 LEDType, u8 LEDState);
void LEDSelector(int LEDState);

#endif
