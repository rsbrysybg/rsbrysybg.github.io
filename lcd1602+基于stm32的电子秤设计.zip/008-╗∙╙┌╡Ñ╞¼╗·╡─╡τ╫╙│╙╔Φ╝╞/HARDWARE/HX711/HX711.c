#include "HX711.h"

//�ο���������C��

unsigned long ReadCount(void)
{
			unsigned long Count;
			unsigned char i;
			ADSK=0;
			Count=0;
			__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();
			while(ADDO);
			for (i=0;i<24;i++)
			{
				ADSK=1;
			__nop();__nop();__nop();__nop();
				Count=Count<<1;
				ADSK=0;
			__nop();__nop();__nop();__nop();
				if(ADDO) Count++;
			}
			
			ADSK=1;
			Count=Count^0x800000;
			__nop();__nop();__nop();__nop();
			ADSK=0;
			return(Count);
}
