#ifndef __MQ_TASK_H__
#define __MQ_TASK_H__

#include "delay.h"
#include "sys.h"
#include "project.h"
#include "adc.h"

typedef struct{
	float AD_Value;
	float	AD_MAX;
	u8		Lora_trigger;
}MQ_2;

extern MQ_2	MQ_Packet;

void MQ_2_TASK (void);

#endif /* __MQ_TASK_H__*/




