#ifndef _NVIC_Config_h_
#define _NVIC_Config_h_
#include"stm32f10x.h"
void NVIC_Config(void);
#endif

