#include "KEY.h."
/**
  * @brief ����GPIO�ĳ�ʼ��
  * @param  None
  * @retval None
  */
static void KEY_GPIO_Init (void)
{
	GPIO_InitTypeDef 			GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIO_InitStruct.GPIO_Pin = Key1|Key2|Key3;
	GPIO_InitStruct.GPIO_Mode =  GPIO_Mode_IPU;
	GPIO_Init(GPIOC, &GPIO_InitStruct);
}
/**
  * @brief 	�����ж�����
  * @param  None
  * @retval None
  */
void KEY_NVIC_Config ( void )
{
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	KEY_GPIO_Init ();
	//��ʼ��NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	//��ʼ��NVIC
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	//��ʼ��EXTI
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	//��ʼ��KEY1 EXTI
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource4);
	EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger =  EXTI_Trigger_Falling ;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	//��ʼ��KEY2 EXTI
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource5);
	EXTI_InitStructure.EXTI_Line = EXTI_Line5;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger =  EXTI_Trigger_Falling ;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
		//��ʼ��KEY3 EXTI
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource6);
	EXTI_InitStructure.EXTI_Line = EXTI_Line6;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger =  EXTI_Trigger_Falling ;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
}

/**
  * @brief �����жϺ���
  * @param  None
  * @retval None
  */

void EXTI4_IRQHandler (void)
{
	if  (EXTI_GetITStatus(EXTI_Line4) != RESET )
	
	{
		Delay_ms (50);
		if(PCin(4)==0)
		{
			KEY1_TASK();
		}
	}
	EXTI_ClearITPendingBit(EXTI_Line4);

}

void EXTI9_5_IRQHandler (void)
{
	
	if  (EXTI_GetITStatus(EXTI_Line5) != RESET )
	{
		Delay_ms (50);
		if(PCin(5)==0)
		{	
			KEY2_TASK();
		}
		EXTI_ClearITPendingBit(EXTI_Line5);
	}
	
		if  (EXTI_GetITStatus(EXTI_Line6) != RESET )
	{
		Delay_ms (50);
		if(PCin(6)==0)
		{	
			KEY3_TASK();
		}
		EXTI_ClearITPendingBit(EXTI_Line6);
	}
	
}

















