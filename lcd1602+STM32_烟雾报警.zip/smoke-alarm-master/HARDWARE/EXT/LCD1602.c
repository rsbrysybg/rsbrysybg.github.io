#include "LCD1602.h"
/**
  * @brief  LCD1602GPIO�ڵĳ�ʼ������
  * @param  None
  * @retval None
  */
static void LCD_GPIO_Init	(void)
{
	GPIO_InitTypeDef	GPIOC_InitStruct;	
	GPIO_InitTypeDef	GPIOB_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIOC_InitStruct.GPIO_Pin=LCD_RS|LCD_RW|LCD_EN;
	GPIOC_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOC_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIOC_InitStruct);
	
	GPIOB_InitStruct.GPIO_Pin = LCD_DB;
	GPIOB_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOB_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIOB_InitStruct);
	
}

/**
  * @brief  LCD1602�ϵ��ʼ������
  * @param  None
  * @retval None
  */
void LCD_INIT(void)
{	
	LCD_GPIO_Init();	
	
	LCD_WRITE_CMD( 0x38 );
	LCD_WRITE_CMD( 0x0C );
	//LCD_WRITE_CMD( 0x0d );	//����������˸
	LCD_WRITE_CMD( 0x06 );		//дһ��ָ��+1
	LCD_WRITE_CMD( 0x01 );		//����
}
/**
  * @brief  LCD1602д�����
  * @param  ����
  * @retval None
  */

void LCD_WRITE_CMD( int CMD   )    
{	
	CMD=CMD<<8;
	ReadBusy();
	GPIO_ResetBits( GPIOC, LCD_RS );
	GPIO_ResetBits( GPIOC, LCD_RW );
	GPIO_ResetBits( GPIOC, LCD_EN );
//	GPIO_Write(GPIOB,CMD);
	GPIOB->ODR=((GPIOB->ODR & 0x00FF)|(CMD&0xFF00));	
	GPIO_SetBits( GPIOC, LCD_EN );;
	GPIO_ResetBits( GPIOC, LCD_EN );
}
/**
  * @brief  ���LCDæ����
  * @param  None
  * @retval None
  */

void ReadBusy(void)
{		
	GPIO_InitTypeDef GPIOB_InitStruct;
	GPIOB_InitStruct.GPIO_Pin = LCD_D7;							
	GPIOB_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;	
	GPIO_Init( GPIOB, &GPIOB_InitStruct );
	
	GPIO_ResetBits( GPIOC, LCD_RS );
	GPIO_SetBits( GPIOC, LCD_RW );
	
	GPIO_SetBits( GPIOC, LCD_EN );	
	while( GPIO_ReadInputDataBit( GPIOB, LCD_D7 ) );	
	GPIO_ResetBits( GPIOC, LCD_EN );
	GPIOB_InitStruct.GPIO_Pin = LCD_D7;		
	GPIOB_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOB_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &GPIOB_InitStruct  );
}

/**
  * @brief  LCD1602д���ݺ���
  * @param	ByteData�� ����
  * @retval None
  */
void LCD_WRITE_ByteDATA( int ByteData )
{	
	ByteData=ByteData<<8;
	ReadBusy();
	GPIO_SetBits( GPIOC, LCD_RS );
	GPIO_ResetBits( GPIOC, LCD_RW );
	GPIO_ResetBits( GPIOC, LCD_EN );
	//GPIO_Write(GPIOB,ByteData);
	GPIOB->ODR=((GPIOB->ODR & 0x00FF)|(ByteData&0xFF00));//PB15-8������λ��PB0-7�����ݲ��ܱ�;
	GPIO_SetBits( GPIOC, LCD_EN );
	GPIO_ResetBits( GPIOC,LCD_EN );;
}
/**
  * @brief  LCD1602д�ַ�������
  * @param  *StrData���ַ���
	* @param	row����ʾ��
	* @param 	col����ʾ��
  * @retval None
  */
void LCD_WRITE_StrDATA( unsigned char *StrData, unsigned char row, unsigned char col )
{
	unsigned char baseAddr = 0x00;			//����256λ��ַ
	if ( row ){
		baseAddr = 0xc0;
	}else{
		baseAddr = 0x80;																				   
	} 	//rowΪ1�û�ѡ��ڶ���
		//rowΪ0�û�ѡ���һ��
	baseAddr += col;

	while ( *StrData != '\0' ){

		LCD_WRITE_CMD( baseAddr );
		LCD_WRITE_ByteDATA( *StrData );

		baseAddr++;			   //ÿ��ѭ����ַ��һ������ָ���һ
		StrData++;
	}
}
