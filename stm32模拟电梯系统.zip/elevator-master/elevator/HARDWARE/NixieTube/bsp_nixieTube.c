/************************************************************************************************************************
 * Filename           : bsp_nixieTube.c
 * Description        : Nixie Tube driver function file
*************************************************************************************************************************/


/* Includes ---------------------------------------------------------------------------------------------------*/
#include "bsp_nixieTube.h"



/* Private typedef --------------------------------------------------------------------------------------------*/
/* Private define ---------------------------------------------------------------------------------------------*/
/* Private macro ----------------------------------------------------------------------------------------------*/
/* Private variables ------------------------------------------------------------------------------------------*/
NIXIE_TUBE_InitTypeDef g_nixieTubeInit[] = 
{
  {NIXIE_TUBE1_LED,NIXIE_TUBE1_PORT,NIXIE_TUBE1_PIN,NIXIE_TUBE_OFF},  
  {NIXIE_TUBE2_LED,NIXIE_TUBE2_PORT,NIXIE_TUBE2_PIN,NIXIE_TUBE_OFF}, 
  {NIXIE_TUBE3_LED,NIXIE_TUBE3_PORT,NIXIE_TUBE3_PIN,NIXIE_TUBE_OFF}, 
  {NIXIE_TUBE4_LED,NIXIE_TUBE4_PORT,NIXIE_TUBE4_PIN,NIXIE_TUBE_OFF}, 
  {NIXIE_TUBE5_LED,NIXIE_TUBE5_PORT,NIXIE_TUBE5_PIN,NIXIE_TUBE_OFF}, 
  {NIXIE_TUBE6_LED,NIXIE_TUBE6_PORT,NIXIE_TUBE6_PIN,NIXIE_TUBE_OFF}, 
  {NIXIE_TUBE7_LED,NIXIE_TUBE7_PORT,NIXIE_TUBE7_PIN,NIXIE_TUBE_OFF}, 
};

static int g_nixieTubeNumber = sizeof(g_nixieTubeInit)/sizeof(g_nixieTubeInit[0]);  /* The number of LEDs need to config         */

/* Private function prototypes --------------------------------------------------------------------------------*/
static void bsp_NixieTubeLedOn(NIXIE_TUBE_NameTypeDef nixieTubeName);
static void bsp_NixieTubeLedOff(NIXIE_TUBE_NameTypeDef nixieTubeName);
static void bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR_NUM_TypeDef floorNum);

/* Private functions ------------------------------------------------------------------------------------------*/


/**************************************************************************************************************
 * Function Name   : bsp_LixieTubeInit
 * Description     : Configures Lixie Tube GPIO
 * Input Variable  : None
 * Return Variable : None
***************************************************************************************************************/
void bsp_LixieTubeInit(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  NIXIE_TUBE_NameTypeDef nixieTubeName;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE); /* Enable PB、PC,RCC_APB2Periph_AFIO clock*/

  for(nixieTubeName = g_nixieTubeInit[0].NixieTubeName;nixieTubeName < (NIXIE_TUBE_NameTypeDef)g_nixieTubeNumber;nixieTubeName++)
  {    
    GPIO_InitStructure.GPIO_Pin   = g_nixieTubeInit[nixieTubeName].NixieTubePin;                
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;        /* Push-pull*/
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(g_nixieTubeInit[nixieTubeName].NixieTubePort, &GPIO_InitStructure);
    
    /* Set the nixie Tube to its initial status                                                                  */
    if (g_nixieTubeInit[nixieTubeName].NixieTubeInitStatus == NIXIE_TUBE_ON)
    {
      bsp_NixieTubeLedOn(nixieTubeName);
    }
    else
    {
      bsp_NixieTubeLedOff(nixieTubeName);
    }
  }
}

/**************************************************************************************************************
 * Function Name   : bsp_NixieTubeLedOff
 * Description     : Turn off a specific led
 * Input Variable  : nixieTubeName
 * Return Variable : None
****************************************************************************************************************/
void bsp_NixieTubeLedOff(NIXIE_TUBE_NameTypeDef nixieTubeName)
{
  g_nixieTubeInit[nixieTubeName].NixieTubePort->BSRR |= g_nixieTubeInit[nixieTubeName].NixieTubePin << 16;
  g_nixieTubeInit[nixieTubeName].NixieTubePort->BSRR &= !g_nixieTubeInit[nixieTubeName].NixieTubePin;
}


/***************************************************************************************************************
 * Function Name   : bsp_NixieTubeLedOn
 * Description     : Turn on a specific led
 * Input Variable  : nixieTubeName
 * Return Variable : None
****************************************************************************************************************/
void bsp_NixieTubeLedOn(NIXIE_TUBE_NameTypeDef nixieTubeName)
{
  g_nixieTubeInit[nixieTubeName].NixieTubePort->BSRR |= g_nixieTubeInit[nixieTubeName].NixieTubePin;
  g_nixieTubeInit[nixieTubeName].NixieTubePort->BSRR &= !(g_nixieTubeInit[nixieTubeName].NixieTubePin << 16);
}

/***************************************************************************************************************
 * Function Name   : bsp_NixieTubeDisplayFloor
 * Description     : Display the floor number in nixie tube
 * Input Variable  : floorNum
 * Return Variable : None
****************************************************************************************************************/
void bsp_NixieTubeDisplayFloor(FLOOR_NumTypeDef floorNum)
{
  switch (floorNum)
  {
    case FLOOR1:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR1);  break;
    case FLOOR2:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR2);  break;
    case FLOOR3:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR3);  break;
    case FLOOR4:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR4);  break;
    case FLOOR5:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR5);  break;
    case FLOOR6:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR6);  break;
    case FLOOR7:bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR7);  break;
  }
}


/***************************************************************************************************************
 * Function Name   : bsp_NixieTubeDisplay
 * Description     : Display the floor number in nixie tube
 * Input Variable  : floorNum
 * Return Variable : None
****************************************************************************************************************/
static void bsp_NixieTubeDisplay(NIXIE_TUBE_FLOOR_NUM_TypeDef floorNum)
{
  NIXIE_TUBE_NameTypeDef nixieTubeName;
  for(nixieTubeName = g_nixieTubeInit[0].NixieTubeName;nixieTubeName < (NIXIE_TUBE_NameTypeDef)g_nixieTubeNumber;nixieTubeName++)
  {       
    if ((floorNum & 0x01) == 0x01)
    {
      bsp_NixieTubeLedOn(nixieTubeName);
    }
    else
    {
      bsp_NixieTubeLedOff(nixieTubeName);
    }
    floorNum >>= 1;
  }
}


/*************************************************END OF FILE***************************************************/



