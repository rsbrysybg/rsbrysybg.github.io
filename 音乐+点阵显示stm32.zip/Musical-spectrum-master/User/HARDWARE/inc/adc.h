#ifndef _ADC_H
#define _ADC_H

  #include "stm32f10x.h"
  
  void ADC1_Init_In0(void);
	u16 ADC1_In0_Data(void);

#endif









