#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"  	 


#define PA8  	 GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8)
#define PA9 	 GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_9)
#define PA10 	 GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10)

void KEY_Init(void);				// IO��ʼ��
char KEY_Scan(void);  				// ����ɨ�躯��
void _Delay (int z);

#endif
