#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h"
//#include "stm32f10x.h" 	 
void EXTIX_Init(void);		//�ⲿ�жϳ�ʼ��
float Input_Price(void);
#endif

