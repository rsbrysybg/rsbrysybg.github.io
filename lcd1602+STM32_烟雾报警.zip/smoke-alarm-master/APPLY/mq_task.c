#include "mq_task.h"

MQ_2	MQ_Packet;

/**
  * @brief  ADCֵ��ȡ����
  * @param  None
  * @retval None
  */

void MQ_2_TASK (void)
{	
		MQ_Packet.AD_Value=ADC_GetValue();
		if(MQ_Packet.AD_Value>=MQ_Packet.AD_MAX)
		{
			MQ_Packet.Lora_trigger=1;
		}
		else
		{
			MQ_Packet.Lora_trigger=0;	
		}
}
