#include "lora_task.h"

/**
  * @brief  LORA���ͺ���
  * @param  None
  * @retval None
  */
void Lora_TX_TASK (void)
{
	u8 i;
//	MQ_Packet.Lora_trigger=1;
	Lora_Packet.TX_Buf[0]=Lora_Packet.My_Addr;
	Lora_Packet.TX_Buf[1]=MQ_Packet.Lora_trigger;
	if(MQ_Packet.Lora_trigger==1)
	{
		for(i=0;i<2;i++)
		{
			Lora_Send(Lora_Packet.TX_Buf[i]);
		}
	}
}
/**
  * @brief 	lora���մ�������
  * @param  None
  * @retval None
  */
void Lora_RX_TASK (void)
{
	Lora_Packet.TX_Buf[0]=Lora_Packet.RX_Buf[0];
	MQ_Packet.Lora_trigger=Lora_Packet.RX_Buf[1];
}

