#include "project.h"

/**
  * @brief  ��������̵���GPIO��ʼ������
  * @param  None
  * @retval None
  */
void FJ_GPIO_Init	(void)
{
	GPIO_InitTypeDef	GPIOC_InitStruct;	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIOC_InitStruct.GPIO_Pin=FMQ_Pin|RELAY_Pin;
	GPIOC_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOC_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIOC_InitStruct);
	RELAY_OFF();
	FMQ_OFF();
}


