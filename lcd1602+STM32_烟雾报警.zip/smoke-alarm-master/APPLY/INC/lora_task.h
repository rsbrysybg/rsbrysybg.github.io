#ifndef __LORA_TASK_H__
#define __LORA_TASK_H__

#include "delay.h"
#include "sys.h"
#include "project.h"
#include "LORA.h"
#include "mq_task.h"

void Lora_TX_TASK (void);
void Lora_RX_TASK (void);

#endif /* __LORA_TASK_H__*/


